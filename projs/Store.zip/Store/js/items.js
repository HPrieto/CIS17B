items = [{
		description: 'Rick and Morty T-Shirt Black',
		price: 25.00,
		image: 'shirt_1.jpg'
	}, {
		description: 'Rick and Morty T-Shirt White',
		price: 25.00,
		image: 'shirt_2.jpeg'
	}, {
		description: 'Rick and Morty Sweater',
		price: 45.00,
		image: 'sweater.jpeg'
	}, {
		description: 'Rick Pillow',
		price: 35.00,
		image: 'pillow.jpg'
	}, {
		description: 'Rick in Action',
		price: 15.00,
		image: 'rick_toy.png'
	}, {
		description: 'Rick as a Mug',
		price: 10.00,
		image: 'mug.jpg'
}]